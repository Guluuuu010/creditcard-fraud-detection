from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

def train_rf(X, y, random_state=42):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=random_state)
    rf = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=random_state)
    rf.fit(X_train, y_train)
    return rf, X_test, y_test
