import joblib, os

def save_model(model, path):
    os.makedirs(path, exist_ok=True)
    joblib.dump(model, path + '/model.joblib')

def load_model(path):
    return joblib.load(path + '/model.joblib')
