import pandas as pd
from sklearn.preprocessing import StandardScaler

def load_data(path):
    return pd.read_csv(path)

def scale_time_amount(df, scaler=None):
    X = df.copy()
    if scaler is None:
        scaler = StandardScaler()
        X[['Time','Amount']] = scaler.fit_transform(X[['Time','Amount']])
        return X, scaler
    else:
        X[['Time','Amount']] = scaler.transform(X[['Time','Amount']])
        return X, scaler
